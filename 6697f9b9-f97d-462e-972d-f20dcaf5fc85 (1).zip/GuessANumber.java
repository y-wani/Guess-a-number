/**
 * Creating a number guessing game
 *
 * @author Yash Wani
 * @version 20210921
 */
import java.util.Scanner;
import java.util.Random;

public class GuessANumber 
{

    public static void main(String[] args) 
    {
       Scanner sc = new Scanner(System.in);
       
       //Inputting a seed value
       System.out.print("Enter a random seed: ");
       int seed = sc.nextInt();
       
       //Creating random variables
       Random rnd = new Random(seed);
       int x = rnd.nextInt(200) + 1;
       
       
       
       int count = 0;
       int num = 0;
       
       //Running a loop to test the conditions
       
       while(num != x)
       {
          System.out.print("Enter a guess between 1 and 200: ");
          num = sc.nextInt();
          sc.nextLine();
          
          if( num != x)  //Checks if the number is in range 
          {
             
              
              if(num < x && num >= 1)
              {
                 System.out.println("Your guess was too low - try again.");
                 count = count + 1;
              }
              else if(num > x && num <= 200)
              {
                 System.out.println("Your guess was too high - try again.");
                 count = count + 1;
              }
              else if(num < 1)
              {
                 System.out.println("Your guess is out of range.  Pick a number between 1 and 200.");
                 System.out.println("Your guess was too low - try again.");
                 count = count + 1;
                 
              }
              else if(num > 200)
              {
                 System.out.println("Your guess is out of range.  Pick a number between 1 and 200.");
                 System.out.println("Your guess was too high - try again.");
                 count = count + 1;
                 
              }
                 
          }
                              
          else if( num == x ) //Checks if the number is equal
          {
             count = count + 1;
             System.out.println("Congratulations!  Your guess was correct!");
             System.out.println();
             System.out.println("I had chosen "+x+" as the target number.");
             System.out.print("You guessed it in "+count+" tries.");
          }
          
             
          
          
          System.out.println();
       } //while loop ends
       
       //if - else blocks to check count and display the respective message
       
       if(count == 1)
       {
          System.out.println("That was impossible!");
       }
       else if(count == 2 || count == 3)
       {
          System.out.println("You're pretty lucky!");
       }
       else if(count >= 4 && count <= 7)
       {
          System.out.println("Not bad, not bad...");
       }
       else if(count == 8)
       {
          System.out.println("That was not very impressive.");
       }
       else if(count == 9 || count == 10)
       {
          System.out.println("Are you having any fun at all?");
       }
       else if(count >= 11)
       {
          System.out.println("Maybe you should play something else.");
       }
      
            
       
       sc.close();
             
             
    
       
       
       
        
    }
}
